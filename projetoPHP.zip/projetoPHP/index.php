<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="Ie-edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Streaming Lovetide - MSFLIX Style</title>
    <link rel="stylesheet" href="css/style.css"> 
    <link rel="stylesheet" href="css/swiper-bundle.min.css"> 
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
</head>
<body>

 <header>
 <div class="nav container"> 
    <a href="index.php" class="logo" title="Streaming Lovetide">
  Love<span>tide</span>
  </a>
       <div class="busca-site">
     <input type="search" id="busca-input" placeholder="Buscar">
     <i class='bx bx-search-alt'></i>
   </div>
       <a href="login.php" class="user" title="Fazer Login ou Acessar Perfil">
    <img src="img/P1.png" alt="Taiyng" class="user-img">
   </a>
      <div class="navbar">
    <a href="#home" class="nav-link">
    <i class='bx bx-home-alt'></i>
    <span class="nav-limk-title">Home</span>
    </a>
    <a href="#popular" class="nav-link">
    <i class='bx bxs-hot'></i>
    <span class="nav-limk-title">Em Alta</span>
    </a>
    <a href="#glb" class="nav-link">
    <i class='bx bx-compass' ></i>
    <span class="nav-limk-title">Explore</span>
    </a>
    <a href="#glb" class="nav-link">
    <i class='bx bx-film'></i>
    <span class="nav-limk-title">GL e BL</span>
    </a>
    <a href="#favoritos" class="nav-link">
    <i class='bx bx-heart'></i>
    <span class="nav-limk-title">Favoritos</span>
    </a>
  </div>
   </div>
 </header>

<section class="banner container" id="home"> 
    
    <div class="banner-video-container">
        <img src="img/home-background.jpg" alt="Player do Filme Girl Rules" class="banner-poster">
    </div>

        <div class="banner-texto">
        <h1 class="banner-titulo">Girl Rules</h1>
                <p>Lançamento em 2026</p>
        <p>Em Girl Rules, acompanhamos um grupo de seis amigas que trabalham juntas e acabam se envolvendo amorosamente de formas nada convencionais. O problema? O passado insiste em bater na porta, e o retorno de uma ex-namorada coloca todas essas relações em jogo. Laços serão testados, corações serão partidos e algumas paixões proibidas vão surgir no caminho. </p>


                        <a href="https://www.youtube.com/watch?v=dF7OAzebldM" class="ver-btn" target="_blank">
        <i class='bx bxs-right-arrow'></i>
        <span>Veja o Trailer</span>
        </a>

    </div>
    
    </section>

<section class="Popular Container" id="popular">
    <div class="topofilmes">
        <h2 class="topotitulos">Em Alta</h2>

        <div class="swiper-btn">
            <div class="swiper-button-prev"></div>
            <div class="swiper-button-next"></div>

        </div>
        
    </div>

<div class="popular-content swiper">
    <div class="swiper-wrapper">
        <div class="swiper-slide">
        <div class="filme-box">
        <img src="img/foto1.png" alt="" class="filmes-box-img">
           <div class="box-titulo">
            <h2 class="titulo-filme">Blank</h2>
            <span class="categoria-filme">Romance</span>
            <a href="ver-fime.php" class="ver-btn play-btn">
            <i class='bx bxs-right-arrow'></i>
            </a>
             </div>
        </div>
        </div>
        
        <div class="swiper-slide">
        <div class="filme-box">
        <img src="img/foto2.png" alt="" class="filmes-box-img">
           <div class="box-titulo">
            <h2 class="titulo-filme">Affair</h2>
            <span class="categoria-filme">Romance</span>
            <a href="ver-fime.php" class="ver-btn play-btn">
            <i class='bx bxs-right-arrow'></i>
            </a>
             </div>
        </div>
        </div>

        <div class="swiper-slide">
        <div class="filme-box">
        <img src="img/foto3.png" alt="" class="filmes-box-img">
           <div class="box-titulo">
            <h2 class="titulo-filme">Whale Store</h2>
            <span class="categoria-filme">Romance</span>
            <a href="ver-fime.php" class="ver-btn play-btn">
            <i class='bx bxs-right-arrow'></i>
            </a>
             </div>
        </div>
        </div>

        <div class="swiper-slide">
        <div class="filme-box">
        <img src="img/foto4.png" alt="" class="filmes-box-img">
           <div class="box-titulo">
            <h2 class="titulo-filme">Harmony Secret</h2>
            <span class="categoria-filme">Romance</span>
            <a href="ver-fime.php" class="ver-btn play-btn">
            <i class='bx bxs-right-arrow'></i>
            </a>
             </div>
        </div>
        </div>

        <div class="swiper-slide">
        <div class="filme-box">
        <img src="img/foto5.png" alt="" class="filmes-box-img">
           <div class="box-titulo">
            <h2 class="titulo-filme">A Man Who Defies the World</h2>
            <span class="categoria-filme">Romance</span>
            <a href="ver-fime.php" class="ver-btn play-btn">
            <i class='bx bxs-right-arrow'></i>
            </a>
             </div>
        </div>
        </div>

        <div class="swiper-slide">
        <div class="filme-box">
        <img src="img/foto6.png" alt="" class="filmes-box-img">
           <div class="box-titulo">
            <h2 class="titulo-filme">Reverse With Me</h2>
            <span class="categoria-filme">Romance</span>
            <a href="ver-fime.php" class="ver-btn play-btn">
            <i class='bx bxs-right-arrow'></i>
            </a>
             </div>
        </div>
        </div>

        <div class="swiper-slide">
        <div class="filme-box">
        <img src="img/foto7.png" alt="" class="filmes-box-img">
           <div class="box-titulo">
            <h2 class="titulo-filme">Only You</h2>
            <span class="categoria-filme">Romance</span>
            <a href="ver-fime.php" class="ver-btn play-btn">
            <i class='bx bxs-right-arrow'></i>
            </a>
             </div>
        </div>
        </div>
    </div>
</div>

</section>

<section class="filmes container" id="glb"> 

  <div class="topofilmes"> 
    <h2 class="topotitulos">GL e BL</h2>
  </div>

  <div class="filmes-content">
  <div class="filme-box">
        <img src="img/foto8.png" alt="" class="filmes-box-img">
           <div class="box-titulo">
            <h2 class="titulo-filme">Cranium</h2>
            <span class="categoria-filme">Romance</span>
            <a href="ver-fime.php" class="ver-btn play-btn">
            <i class='bx bxs-right-arrow'></i>
            </a>
             </div>
        </div>

        <div class="filme-box">
        <img src="img/foto9.png" alt="" class="filmes-box-img">
           <div class="box-titulo">
            <h2 class="titulo-filme">Pethichor</h2>
            <span class="categoria-filme">Romance</span>
            <a href="ver-fime.php" class="ver-btn play-btn">
            <i class='bx bxs-right-arrow'></i>
            </a>
             </div>
        </div>

        <div class="filme-box">
        <img src="img/foto10.png" alt="" class="filmes-box-img">
           <div class="box-titulo">
            <h2 class="titulo-filme">Reverse 4 You</h2>
            <span class="categoria-filme">Romance</span>
            <a href="ver-fime.php" class="ver-btn play-btn">
            <i class='bx bxs-right-arrow'></i>
            </a>
             </div>
        </div>

        <div class="filme-box">
        <img src="img/foto11.png" alt="" class="filmes-box-img">
           <div class="box-titulo">
            <h2 class="titulo-filme">Blood</h2>
            <span class="categoria-filme">Romance</span>
            <a href="ver-fime.php" class="ver-btn play-btn">
            <i class='bx bxs-right-arrow'></i>
            </a>
             </div>
        </div>

        <div class="filme-box">
        <img src="img/foto12.png" alt="" class="filmes-box-img">
           <div class="box-titulo">
            <h2 class="titulo-filme">Love Hell</h2>
            <span class="categoria-filme">Romance</span>
            <a href="ver-fime.php" class="ver-btn play-btn">
            <i class='bx bxs-right-arrow'></i>
            </a>
             </div>
        </div>

        <div class="filme-box">
        <img src="img/foto13.png" alt="" class="filmes-box-img">
           <div class="box-titulo">
            <h2 class="titulo-filme">The Loyal Pin</h2>
            <span class="categoria-filme">Romance</span>
            <a href="ver-fime.php" class="ver-btn play-btn">
            <i class='bx bxs-right-arrow'></i>
            </a>
             </div>
        </div>

        <div class="filme-box">
        <img src="img/foto14.png" alt="" class="filmes-box-img">
           <div class="box-titulo">
            <h2 class="titulo-filme">Us</h2>
            <span class="categoria-filme">Romance</span>
            <a href="ver-fime.php" class="ver-btn play-btn">
            <i class='bx bxs-right-arrow'></i>
            </a>
             </div>
        </div>

  </div>
</section>

<section class="container" id="favoritos"></section>

<footer class="direitos">
    <p>&#169; todos os direitos reservados a Lovetide.com.br</p>
 </footer>


<script src="js/swiper-bundle.min.js"> </script>
<script src="js/scripts.js"> </script>
    
</body>
</html>